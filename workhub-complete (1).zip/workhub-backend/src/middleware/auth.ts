import { Request, Response, NextFunction } from 'express'
import jwt from 'jsonwebtoken'
import { db } from '../lib/db'

export interface AuthRequest extends Request {
  user?: { id: string; email: string; role: string }
}

// ── Verify JWT ────────────────────────────────────────────────────────────────
export function authMiddleware(req: AuthRequest, res: Response, next: NextFunction) {
  const header = req.headers.authorization
  if (!header?.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Missing or invalid Authorization header' })
  }
  const token = header.slice(7)
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET!) as {
      id: string; email: string; role: string
    }
    req.user = payload
    next()
  } catch {
    return res.status(401).json({ error: 'Token expired or invalid' })
  }
}

// ── Optional auth (doesn't fail if no token) ─────────────────────────────────
export function optionalAuth(req: AuthRequest, _res: Response, next: NextFunction) {
  const header = req.headers.authorization
  if (header?.startsWith('Bearer ')) {
    try {
      const payload = jwt.verify(header.slice(7), process.env.JWT_SECRET!) as any
      req.user = payload
    } catch {}
  }
  next()
}

// ── Role guards ───────────────────────────────────────────────────────────────
export const requireRole = (...roles: string[]) =>
  (req: AuthRequest, res: Response, next: NextFunction) => {
    if (!req.user) return res.status(401).json({ error: 'Unauthorized' })
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ error: `Access restricted to: ${roles.join(', ')}` })
    }
    next()
  }

export const requireAdmin    = requireRole('ADMIN')
export const requireClient   = requireRole('CLIENT', 'ADMIN')
export const requireFreelancer = requireRole('FREELANCER', 'ADMIN')
export const requireWorker   = requireRole('ONSITE_WORKER', 'ADMIN')
export const requireEnterprise = requireRole('ENTERPRISE', 'ADMIN')
