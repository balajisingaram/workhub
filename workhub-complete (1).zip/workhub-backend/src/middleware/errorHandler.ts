// ── errorHandler.ts ───────────────────────────────────────────────────────────
import { Request, Response, NextFunction } from 'express'

export function errorHandler(err: any, _req: Request, res: Response, _next: NextFunction) {
  const status  = err.status ?? err.statusCode ?? 500
  const message = err.message ?? 'Internal server error'

  if (process.env.NODE_ENV !== 'production') console.error('[Error]', err)

  // Prisma unique constraint
  if (err.code === 'P2002') return res.status(409).json({ error: 'A record with this value already exists' })
  // Prisma not found
  if (err.code === 'P2025') return res.status(404).json({ error: 'Record not found' })

  res.status(status).json({ error: message })
}
