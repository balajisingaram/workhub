import { Queue, Worker, QueueEvents } from 'bullmq'
import IORedis from 'ioredis'
import { db } from '../lib/db'
import { emailService } from '../services/email'
import { v4 as uuid } from 'uuid'

const connection = new IORedis(process.env.REDIS_URL!, { maxRetriesPerRequest: null })

// ── QUEUE DEFINITIONS ─────────────────────────────────────────────────────────
export const emailQueue        = new Queue('email',         { connection })
export const bulkUploadQueue   = new Queue('bulk-upload',   { connection })
export const withdrawalQueue   = new Queue('withdrawal',    { connection })
export const notificationQueue = new Queue('notifications', { connection })
export const pdfQueue          = new Queue('pdf-generation',{ connection })

// ── EMAIL WORKER ──────────────────────────────────────────────────────────────
new Worker('email', async (job) => {
  const { type, ...data } = job.data

  switch (type) {
    case 'verification':
      await emailService.sendVerificationEmail(data.to, data.name, data.token)
      break
    case 'employee-verification':
      await emailService.sendEmployeeVerification(data.to, data.name, data.token, data.enterpriseId)
      break
    case 'shift-assignment':
      await emailService.sendShiftAssignment(data.to, data.name, data.shiftTitle, data.shiftDate, data.enterpriseId)
      break
    case 'payment-released':
      await emailService.sendPaymentReleased(data.to, data.amount, data.jobTitle)
      break
    case 'proposal-received':
      await emailService.sendProposalReceived(data.to, data.jobTitle, data.proposalCount)
      break
  }
}, { connection })

// ── BULK EMPLOYEE UPLOAD WORKER ───────────────────────────────────────────────
new Worker('bulk-upload', async (job) => {
  const { enterpriseId, rows } = job.data as {
    enterpriseId: string
    rows: Array<{
      name: string
      email: string
      role: string
      department?: string
      weightTier?: string
      phone?: string
    }>
  }

  const results = { success: 0, failed: 0, errors: [] as string[] }

  for (const row of rows) {
    try {
      // Skip duplicates
      const existing = await db.employee.findFirst({ where: { enterpriseId, email: row.email } })
      if (existing) { results.errors.push(`${row.email}: already exists`); results.failed++; continue }

      const token  = uuid()
      const expiry = new Date(Date.now() + 1000 * 60 * 60 * 72) // 72 hours

      await db.employee.create({
        data: {
          enterpriseId,
          name:              row.name,
          email:             row.email,
          role:              row.role,
          department:        row.department,
          phone:             row.phone,
          weightTier:        row.weightTier as any,
          verifyToken:       token,
          verifyTokenExpiry: expiry,
        },
      })

      // Queue verification email
      await emailQueue.add('send', {
        type:         'employee-verification',
        to:           row.email,
        name:         row.name,
        token,
        enterpriseId,
      })

      results.success++
    } catch (err: any) {
      results.failed++
      results.errors.push(`${row.email}: ${err.message}`)
    }

    // Update job progress
    await job.updateProgress(Math.round(((results.success + results.failed) / rows.length) * 100))
  }

  return results
}, { connection, concurrency: 3 })

// ── WITHDRAWAL WORKER ─────────────────────────────────────────────────────────
new Worker('withdrawal', async (job) => {
  const { userId, amountUSD } = job.data
  const user = await db.user.findUnique({ where: { id: userId }, include: { wallet: true } })
  if (!user?.wallet) throw new Error('Wallet not found')

  // In production: create Stripe Connect payout
  // const payout = await stripe.payouts.create({ amount: Math.round(amountUSD * 100), currency: 'usd' }, { stripeAccount: user.stripeConnectId })
  console.log(`[Withdrawal] Processing $${amountUSD} withdrawal for user ${userId}`)
}, { connection })

// ── PDF GENERATION WORKER ─────────────────────────────────────────────────────
new Worker('pdf-generation', async (job) => {
  const { type, ...data } = job.data

  if (type === 'payslip') {
    const { generatePayslipPDF } = await import('../services/pdf')
    const buffer = await generatePayslipPDF(data)
    // Upload to S3 and return URL
    const { uploadJSON } = await import('../services/storage')
    return uploadJSON(buffer, 'payslips')
  }

  if (type === 'invoice') {
    const { generateInvoicePDF } = await import('../services/pdf')
    const buffer = await generateInvoicePDF(data)
    return buffer
  }
}, { connection })

// ── NOTIFICATION WORKER ───────────────────────────────────────────────────────
new Worker('notifications', async (job) => {
  const { userId, title, body } = job.data
  // In production: send via Firebase FCM / OneSignal
  console.log(`[Push] → ${userId}: ${title}`)
}, { connection })

export { connection as redisConnection }
