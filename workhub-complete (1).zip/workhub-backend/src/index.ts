import 'dotenv/config'
import express from 'express'
import http from 'http'
import { Server as SocketIO } from 'socket.io'
import cors from 'cors'
import helmet from 'helmet'
import compression from 'compression'
import morgan from 'morgan'
import rateLimit from 'express-rate-limit'

import { errorHandler } from './middleware/errorHandler'
import { authMiddleware } from './middleware/auth'

// Routes
import authRoutes        from './routes/auth'
import userRoutes        from './routes/users'
import freelancerRoutes  from './routes/freelancers'
import workerRoutes      from './routes/workers'
import jobRoutes         from './routes/jobs'
import proposalRoutes    from './routes/proposals'
import paymentRoutes     from './routes/payments'
import messageRoutes     from './routes/messages'
import enterpriseRoutes  from './routes/enterprise'
import employeeRoutes    from './routes/employees'
import shiftRoutes       from './routes/shifts'
import reviewRoutes      from './routes/reviews'
import adminRoutes       from './routes/admin'
import uploadRoutes      from './routes/upload'
import webhookRoutes     from './routes/webhooks'
import notificationRoutes from './routes/notifications'

// Socket handler
import { registerSocketHandlers } from './lib/socket'

const app    = express()
const server = http.createServer(app)

// ── Socket.io ──────────────────────────────────────────────────────────────
export const io = new SocketIO(server, {
  cors: { origin: process.env.FRONTEND_URL ?? 'http://localhost:3000', credentials: true },
})
registerSocketHandlers(io)

// ── Core middleware ────────────────────────────────────────────────────────
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }))
app.use(compression())
app.use(cors({ origin: process.env.FRONTEND_URL ?? 'http://localhost:3000', credentials: true }))
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'))

// Stripe webhooks need raw body
app.use('/api/webhooks/stripe',   express.raw({ type: 'application/json' }))
app.use('/api/webhooks/razorpay', express.raw({ type: 'application/json' }))
app.use(express.json({ limit: '10mb' }))
app.use(express.urlencoded({ extended: true, limit: '10mb' }))

// ── Rate limiting ──────────────────────────────────────────────────────────
const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 200, standardHeaders: true })
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 20, message: 'Too many auth attempts' })
app.use('/api/', limiter)
app.use('/api/auth/', authLimiter)

// ── Health check ───────────────────────────────────────────────────────────
app.get('/health', (_req, res) => res.json({ status: 'ok', time: new Date().toISOString() }))

// ── Public routes ──────────────────────────────────────────────────────────
app.use('/api/auth',      authRoutes)
app.use('/api/webhooks',  webhookRoutes)

// ── Protected routes ───────────────────────────────────────────────────────
app.use('/api/users',       authMiddleware, userRoutes)
app.use('/api/freelancers', freelancerRoutes)      // Some endpoints public
app.use('/api/workers',     workerRoutes)          // Some endpoints public
app.use('/api/jobs',        jobRoutes)             // Some endpoints public
app.use('/api/proposals',   authMiddleware, proposalRoutes)
app.use('/api/payments',    authMiddleware, paymentRoutes)
app.use('/api/messages',    authMiddleware, messageRoutes)
app.use('/api/enterprise',  authMiddleware, enterpriseRoutes)
app.use('/api/employees',   authMiddleware, employeeRoutes)
app.use('/api/shifts',      authMiddleware, shiftRoutes)
app.use('/api/reviews',     authMiddleware, reviewRoutes)
app.use('/api/admin',       authMiddleware, adminRoutes)
app.use('/api/upload',      authMiddleware, uploadRoutes)
app.use('/api/notifications', authMiddleware, notificationRoutes)

// ── Error handler ──────────────────────────────────────────────────────────
app.use(errorHandler)

// ── Start ──────────────────────────────────────────────────────────────────
const PORT = process.env.PORT ?? 4000
server.listen(PORT, () => {
  console.log(`\n🚀 WorkHub API running on http://localhost:${PORT}`)
  console.log(`📡 Socket.io active`)
  console.log(`🌍 Env: ${process.env.NODE_ENV ?? 'development'}\n`)
})

export default app
