import AWS from 'aws-sdk'
import multer from 'multer'
import multerS3 from 'multer-s3'
import { v4 as uuid } from 'uuid'
import path from 'path'

const s3 = new AWS.S3({
  region:          process.env.AWS_REGION!,
  accessKeyId:     process.env.AWS_ACCESS_KEY_ID!,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY!,
})

const PUBLIC_BUCKET  = process.env.AWS_S3_BUCKET!         // freelancer photos, portfolio
const PRIVATE_BUCKET = process.env.AWS_S3_PRIVATE_BUCKET! // ID docs, onsite worker photos

// ── UPLOAD TO PUBLIC BUCKET (freelancer photos, portfolio) ────────────────────
export const publicUpload = multer({
  storage: multerS3({
    s3,
    bucket: PUBLIC_BUCKET,
    acl:    'public-read',
    key:    (_req, file, cb) => {
      const ext = path.extname(file.originalname)
      cb(null, `uploads/${uuid()}${ext}`)
    },
  }),
  limits:    { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (_req, file, cb) => {
    const allowed = ['image/jpeg','image/png','image/webp','image/gif','application/pdf']
    cb(null, allowed.includes(file.mimetype))
  },
})

// ── UPLOAD TO PRIVATE BUCKET (ID docs, onsite worker photos) ─────────────────
export const privateUpload = multer({
  storage: multerS3({
    s3,
    bucket: PRIVATE_BUCKET,
    acl:    'private',
    key:    (_req, file, cb) => {
      const ext = path.extname(file.originalname)
      cb(null, `private/${uuid()}${ext}`)
    },
  }),
  limits:    { fileSize: 20 * 1024 * 1024 }, // 20MB
})

// ── PRESIGNED URL (temporary access to private files) ────────────────────────
export async function getPresignedUrl(key: string, expiresIn = 3600): Promise<string> {
  return s3.getSignedUrlPromise('getObject', {
    Bucket:  PRIVATE_BUCKET,
    Key:     key,
    Expires: expiresIn, // seconds
  })
}

// ── DELETE FILE ───────────────────────────────────────────────────────────────
export async function deleteFile(key: string, isPrivate = false): Promise<void> {
  await s3.deleteObject({
    Bucket: isPrivate ? PRIVATE_BUCKET : PUBLIC_BUCKET,
    Key:    key,
  }).promise()
}

// ── BULK UPLOAD (for CSV parsing results stored as JSON) ──────────────────────
export async function uploadJSON(data: object, folder = 'exports'): Promise<string> {
  const key = `${folder}/${uuid()}.json`
  await s3.putObject({
    Bucket:      PUBLIC_BUCKET,
    Key:         key,
    Body:        JSON.stringify(data),
    ContentType: 'application/json',
  }).promise()
  return key
}
