import nodemailer from 'nodemailer'
import sgMail from '@sendgrid/mail'
import { db } from '../lib/db'

sgMail.setApiKey(process.env.SENDGRID_API_KEY!)

// ── BASE EMAIL TEMPLATE ───────────────────────────────────────────────────────
function baseTemplate(opts: {
  companyName: string
  logoUrl?: string
  brandColor: string
  title: string
  body: string
  ctaText?: string
  ctaUrl?: string
  footerDomain?: string
}): string {
  return `
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"/><meta name="viewport" content="width=device-width,initial-scale=1.0"/></head>
<body style="margin:0;padding:0;background:#f5f3ee;font-family:'DM Sans',Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0">
    <tr><td align="center" style="padding:40px 20px;">
      <table width="560" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:16px;overflow:hidden;border:1px solid rgba(20,18,14,.08);">
        <!-- Header -->
        <tr>
          <td style="background:${opts.brandColor};padding:28px 36px;">
            ${opts.logoUrl
              ? `<img src="${opts.logoUrl}" height="36" alt="${opts.companyName}" style="display:block"/>`
              : `<div style="font-size:22px;font-weight:900;color:#ffffff;letter-spacing:-0.5px;">${opts.companyName}</div>`
            }
          </td>
        </tr>
        <!-- Body -->
        <tr>
          <td style="padding:36px;color:#14120e;">
            <h2 style="margin:0 0 16px;font-size:22px;font-weight:700;letter-spacing:-0.5px;">${opts.title}</h2>
            <div style="font-size:15px;line-height:1.7;color:#3a3630;">${opts.body}</div>
            ${opts.ctaText && opts.ctaUrl ? `
            <div style="margin:28px 0;">
              <a href="${opts.ctaUrl}" style="background:${opts.brandColor};color:#ffffff;padding:14px 28px;border-radius:24px;text-decoration:none;font-weight:700;font-size:14px;display:inline-block;">
                ${opts.ctaText}
              </a>
            </div>` : ''}
          </td>
        </tr>
        <!-- Footer -->
        <tr>
          <td style="background:#f5f3ee;padding:20px 36px;border-top:1px solid rgba(20,18,14,.06);">
            <div style="font-size:12px;color:#7a756c;">
              © ${new Date().getFullYear()} ${opts.companyName}
              ${opts.footerDomain ? ` · ${opts.footerDomain}` : ''}
            </div>
          </td>
        </tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`
}

// ── GET TENANT SMTP CONFIG ────────────────────────────────────────────────────
async function getTenantConfig(enterpriseId?: string) {
  if (!enterpriseId) {
    return {
      companyName: 'WorkHub',
      brandColor:  '#1a6b3c',
      logoUrl:     undefined,
      fromName:    'WorkHub',
      fromEmail:   process.env.EMAIL_FROM ?? 'noreply@workhub.com',
      smtpHost:    undefined as string | undefined,
      footerDomain: 'workhub.com',
    }
  }

  const ent = await db.enterprise.findUnique({ where: { id: enterpriseId } })
  return {
    companyName:  ent?.companyName ?? 'WorkHub',
    brandColor:   ent?.brandColor  ?? '#1a6b3c',
    logoUrl:      ent?.logoUrl,
    fromName:     ent?.fromEmailName ?? ent?.companyName ?? 'WorkHub',
    fromEmail:    ent?.fromEmail    ?? process.env.EMAIL_FROM!,
    smtpHost:     ent?.smtpHost,
    smtpUser:     ent?.smtpUser,
    smtpPass:     ent?.smtpPassEnc, // should be decrypted in prod
    footerDomain: ent?.customDomain,
  }
}

// ── SEND EMAIL ────────────────────────────────────────────────────────────────
async function sendEmail(opts: {
  to: string
  subject: string
  html: string
  enterpriseId?: string
  fromName?: string
  fromEmail?: string
  smtpHost?: string
  smtpUser?: string
  smtpPass?: string
}) {
  // Use tenant SMTP if configured, else fall back to SendGrid
  if (opts.smtpHost && opts.smtpUser && opts.smtpPass) {
    const transporter = nodemailer.createTransport({
      host: opts.smtpHost,
      port: 587,
      secure: false,
      auth: { user: opts.smtpUser, pass: opts.smtpPass },
    })
    await transporter.sendMail({
      from:    `"${opts.fromName}" <${opts.fromEmail}>`,
      to:      opts.to,
      subject: opts.subject,
      html:    opts.html,
    })
  } else {
    await sgMail.send({
      from:    { name: opts.fromName ?? 'WorkHub', email: opts.fromEmail ?? process.env.EMAIL_FROM! },
      to:      opts.to,
      subject: opts.subject,
      html:    opts.html,
    })
  }
}

// ── EMAIL METHODS ─────────────────────────────────────────────────────────────
export const emailService = {

  async sendVerificationEmail(to: string, name: string, token: string) {
    const cfg  = await getTenantConfig()
    const url  = `${process.env.NEXT_PUBLIC_APP_URL}/api/auth/verify-email/${token}`
    const html = baseTemplate({
      ...cfg,
      title:    `Welcome to ${cfg.companyName}, ${name.split(' ')[0]}!`,
      body:     `Thanks for signing up. Click below to verify your email address and activate your account.`,
      ctaText:  'Verify my email',
      ctaUrl:   url,
    })
    await sendEmail({ to, subject: `Verify your ${cfg.companyName} account`, html, ...cfg })
  },

  async sendPasswordReset(to: string, token: string) {
    const cfg  = await getTenantConfig()
    const url  = `${process.env.NEXT_PUBLIC_APP_URL}/reset-password?token=${token}`
    const html = baseTemplate({
      ...cfg,
      title:   'Reset your password',
      body:    'We received a request to reset your password. Click below — this link expires in 1 hour.',
      ctaText: 'Reset password',
      ctaUrl:  url,
    })
    await sendEmail({ to, subject: `Reset your ${cfg.companyName} password`, html, ...cfg })
  },

  // White-label employee verification email
  async sendEmployeeVerification(to: string, name: string, token: string, enterpriseId: string) {
    const cfg  = await getTenantConfig(enterpriseId)
    const url  = `${cfg.footerDomain ? 'https://' + cfg.footerDomain : process.env.NEXT_PUBLIC_APP_URL}/verify?token=${token}`
    const html = baseTemplate({
      ...cfg,
      title:   `Welcome to ${cfg.companyName}`,
      body:    `Hi ${name.split(' ')[0]},<br/><br/>You've been added to our team portal. Click below to verify your account and set your password.`,
      ctaText: 'Verify my account',
      ctaUrl:  url,
    })
    // Sends from company SMTP — employees never see WorkHub branding
    await sendEmail({ to, subject: `Welcome to ${cfg.companyName} — verify your account`, html, ...cfg })
  },

  async sendShiftAssignment(to: string, employeeName: string, shiftTitle: string, shiftDate: string, enterpriseId: string) {
    const cfg  = await getTenantConfig(enterpriseId)
    const html = baseTemplate({
      ...cfg,
      title: 'New shift assigned',
      body:  `Hi ${employeeName.split(' ')[0]},<br/><br/>You have been assigned to: <strong>${shiftTitle}</strong> on <strong>${shiftDate}</strong>.<br/><br/>Please log in to your portal to confirm.`,
      ctaText: 'View shift details',
      ctaUrl:  `https://${cfg.footerDomain ?? 'workhub.com'}/dashboard`,
    })
    await sendEmail({ to, subject: `New shift: ${shiftTitle}`, html, ...cfg })
  },

  async sendPaymentReleased(to: string, amount: number, jobTitle: string) {
    const cfg  = await getTenantConfig()
    const html = baseTemplate({
      ...cfg,
      title: 'Payment released 💸',
      body:  `Your payment of <strong>$${amount.toFixed(2)}</strong> for "<em>${jobTitle}</em>" has been released to your wallet. You can withdraw to your bank account at any time.`,
      ctaText: 'View earnings',
      ctaUrl:  `${process.env.NEXT_PUBLIC_APP_URL}/dashboard`,
    })
    await sendEmail({ to, subject: `$${amount.toFixed(2)} released to your wallet`, html, ...cfg })
  },

  async sendHireConfirmation(to: string, clientName: string, jobTitle: string) {
    const cfg  = await getTenantConfig()
    const html = baseTemplate({
      ...cfg,
      title: `You've been hired! 🎉`,
      body:  `Congratulations — <strong>${clientName}</strong> has hired you for "<em>${jobTitle}</em>". The payment has been placed in escrow. Get started and deliver great work!`,
      ctaText: 'View job',
      ctaUrl:  `${process.env.NEXT_PUBLIC_APP_URL}/dashboard`,
    })
    await sendEmail({ to, subject: `You've been hired for: ${jobTitle}`, html, ...cfg })
  },

  async sendProposalReceived(to: string, jobTitle: string, proposalCount: number) {
    const cfg  = await getTenantConfig()
    const html = baseTemplate({
      ...cfg,
      title: `New proposal on your job`,
      body:  `You now have <strong>${proposalCount} proposal${proposalCount > 1 ? 's' : ''}</strong> for "<em>${jobTitle}</em>". Review them and find the perfect candidate.`,
      ctaText: 'Review proposals',
      ctaUrl:  `${process.env.NEXT_PUBLIC_APP_URL}/dashboard`,
    })
    await sendEmail({ to, subject: `New proposal: ${jobTitle}`, html, ...cfg })
  },
}
