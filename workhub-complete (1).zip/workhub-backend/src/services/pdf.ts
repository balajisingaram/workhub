import PDFDocument from 'pdfkit'

interface PayslipData {
  companyName:  string
  companyLogo?: string
  brandColor:   string
  employeeName: string
  employeeRole: string
  period:       string
  items: Array<{ label: string; hours?: number; rate?: number; amount: number }>
  totalGross:   number
  deductions:   Array<{ label: string; amount: number }>
  totalNet:     number
  currency:     string
}

interface InvoiceData {
  companyName:    string
  companyAddress: string
  brandColor:     string
  invoiceNumber:  string
  issuedDate:     string
  dueDate:        string
  clientName:     string
  clientEmail:    string
  items: Array<{ description: string; qty: number; rate: number; amount: number }>
  subtotal:       number
  platformFee:    number
  total:          number
  currency:       string
  notes?:         string
}

// ── HELPERS ───────────────────────────────────────────────────────────────────
function hexToRgb(hex: string): [number, number, number] {
  const r = parseInt(hex.slice(1, 3), 16)
  const g = parseInt(hex.slice(3, 5), 16)
  const b = parseInt(hex.slice(5, 7), 16)
  return [r, g, b]
}

function bufferFromDoc(doc: PDFKit.PDFDocument): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = []
    doc.on('data',  (c: Buffer) => chunks.push(c))
    doc.on('end',   () => resolve(Buffer.concat(chunks)))
    doc.on('error', reject)
    doc.end()
  })
}

// ── PAYSLIP ───────────────────────────────────────────────────────────────────
export async function generatePayslipPDF(data: PayslipData): Promise<Buffer> {
  const doc  = new PDFDocument({ size: 'A4', margin: 50 })
  const [r, g, b] = hexToRgb(data.brandColor)

  // ── Header band ────────────────────────────────────────────────────────────
  doc.rect(0, 0, 595, 100).fill([r, g, b])
  doc.fontSize(22).font('Helvetica-Bold').fillColor('#ffffff')
     .text(data.companyName, 50, 32)
  doc.fontSize(10).font('Helvetica').fillColor('rgba(255,255,255,0.7)')
     .text('PAYSLIP', 50, 58)

  // ── Employee details ───────────────────────────────────────────────────────
  doc.fillColor('#14120e')
  doc.fontSize(16).font('Helvetica-Bold').text(data.employeeName, 50, 120)
  doc.fontSize(11).font('Helvetica').fillColor('#7a756c')
     .text(data.employeeRole, 50, 140)
     .text(`Pay period: ${data.period}`, 50, 158)

  // ── Earnings table ─────────────────────────────────────────────────────────
  let y = 200
  doc.fontSize(12).font('Helvetica-Bold').fillColor('#14120e').text('Earnings', 50, y)
  y += 20
  doc.moveTo(50, y).lineTo(545, y).strokeColor('#ece9e3').lineWidth(1).stroke()
  y += 12

  for (const item of data.items) {
    doc.fontSize(10).font('Helvetica').fillColor('#3a3630')
    doc.text(item.label,                             50, y)
    if (item.hours) doc.text(`${item.hours}h × ${data.currency}${item.rate}`, 250, y)
    doc.font('Helvetica-Bold').text(`${data.currency}${item.amount.toFixed(2)}`, 490, y, { align: 'right', width: 55 })
    y += 22
  }

  // ── Gross total ────────────────────────────────────────────────────────────
  y += 8
  doc.rect(50, y, 495, 28).fill('#f5f3ee')
  doc.fontSize(11).font('Helvetica-Bold').fillColor('#14120e')
     .text('Gross pay', 60, y + 8)
     .text(`${data.currency}${data.totalGross.toFixed(2)}`, 490, y + 8, { align: 'right', width: 55 })

  y += 48

  // ── Deductions ─────────────────────────────────────────────────────────────
  doc.fontSize(12).font('Helvetica-Bold').fillColor('#14120e').text('Deductions', 50, y)
  y += 20
  doc.moveTo(50, y).lineTo(545, y).strokeColor('#ece9e3').lineWidth(1).stroke()
  y += 12

  for (const d of data.deductions) {
    doc.fontSize(10).font('Helvetica').fillColor('#3a3630').text(d.label, 50, y)
    doc.font('Helvetica-Bold').fillColor('#c94040')
       .text(`−${data.currency}${d.amount.toFixed(2)}`, 490, y, { align: 'right', width: 55 })
    y += 22
  }

  // ── Net pay ────────────────────────────────────────────────────────────────
  y += 16
  doc.rect(50, y, 495, 40).fill([r, g, b])
  doc.fontSize(14).font('Helvetica-Bold').fillColor('#ffffff')
     .text('Net Pay', 60, y + 12)
     .text(`${data.currency}${data.totalNet.toFixed(2)}`, 490, y + 12, { align: 'right', width: 55 })

  // ── Footer ─────────────────────────────────────────────────────────────────
  doc.fontSize(9).font('Helvetica').fillColor('#b0a99e')
     .text('This is a system-generated payslip. No signature required.', 50, 750, { align: 'center', width: 495 })

  return bufferFromDoc(doc)
}

// ── INVOICE ───────────────────────────────────────────────────────────────────
export async function generateInvoicePDF(data: InvoiceData): Promise<Buffer> {
  const doc  = new PDFDocument({ size: 'A4', margin: 50 })
  const [r, g, b] = hexToRgb(data.brandColor)

  // ── Header ─────────────────────────────────────────────────────────────────
  doc.rect(0, 0, 595, 90).fill([r, g, b])
  doc.fontSize(24).font('Helvetica-Bold').fillColor('#ffffff')
     .text(data.companyName, 50, 28)
  doc.fontSize(10).font('Helvetica').fillColor('rgba(255,255,255,.65)')
     .text('INVOICE', 490, 35, { align: 'right', width: 55 })

  // ── Invoice meta ───────────────────────────────────────────────────────────
  doc.fillColor('#14120e')
  doc.fontSize(11).font('Helvetica')
  let y = 110
  const meta = [
    ['Invoice number', data.invoiceNumber],
    ['Issued date',    data.issuedDate],
    ['Due date',       data.dueDate],
  ]
  for (const [label, value] of meta) {
    doc.fillColor('#7a756c').text(label, 50, y)
    doc.fillColor('#14120e').font('Helvetica-Bold').text(value, 200, y)
    doc.font('Helvetica')
    y += 18
  }

  // ── Bill to ────────────────────────────────────────────────────────────────
  y += 10
  doc.fontSize(11).font('Helvetica-Bold').fillColor('#14120e').text('Bill to', 50, y)
  y += 18
  doc.font('Helvetica').fillColor('#3a3630')
     .text(data.clientName,  50, y)
     .text(data.clientEmail, 50, y + 16)

  // ── Line items ─────────────────────────────────────────────────────────────
  y += 60
  const cols = [50, 280, 380, 430, 490]
  const hdrs = ['Description', 'Qty', 'Rate', 'Amount']
  doc.rect(50, y, 495, 24).fill('#f5f3ee')
  doc.fontSize(10).font('Helvetica-Bold').fillColor('#7a756c')
  hdrs.forEach((h, i) => doc.text(h, cols[i], y + 7))
  y += 28

  for (const item of data.items) {
    doc.fontSize(10).font('Helvetica').fillColor('#3a3630')
    doc.text(item.description,            cols[0], y, { width: 220 })
    doc.text(String(item.qty),            cols[1], y)
    doc.text(`${data.currency}${item.rate}`, cols[2], y)
    doc.font('Helvetica-Bold')
       .text(`${data.currency}${item.amount.toFixed(2)}`, cols[4], y, { align: 'right', width: 55 })
    y += 24
  }

  // ── Totals ─────────────────────────────────────────────────────────────────
  y += 12
  doc.moveTo(350, y).lineTo(545, y).strokeColor('#ece9e3').lineWidth(1).stroke()
  y += 12

  const totals: Array<[string, string, boolean]> = [
    ['Subtotal',     `${data.currency}${data.subtotal.toFixed(2)}`,    false],
    ['Platform fee', `−${data.currency}${data.platformFee.toFixed(2)}`, false],
    ['Total due',    `${data.currency}${data.total.toFixed(2)}`,        true],
  ]
  for (const [label, value, bold] of totals) {
    doc.fontSize(bold ? 13 : 10)
       .font(bold ? 'Helvetica-Bold' : 'Helvetica')
       .fillColor(bold ? '#14120e' : '#7a756c')
       .text(label, 350, y)
       .fillColor(bold ? [r, g, b] : '#14120e')
       .text(value, 490, y, { align: 'right', width: 55 })
    y += bold ? 28 : 20
  }

  if (data.notes) {
    y += 20
    doc.fontSize(9).font('Helvetica-Bold').fillColor('#7a756c').text('Notes', 50, y)
    doc.font('Helvetica').text(data.notes, 50, y + 14, { width: 495 })
  }

  doc.fontSize(9).font('Helvetica').fillColor('#b0a99e')
     .text('Thank you for your business.', 50, 760, { align: 'center', width: 495 })

  return bufferFromDoc(doc)
}
