import Stripe from 'stripe'
import Razorpay from 'razorpay'
import { db } from '../lib/db'
import { notifyService } from './notifications'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: '2024-06-20' })

const razorpay = new Razorpay({
  key_id:     process.env.RAZORPAY_KEY_ID!,
  key_secret: process.env.RAZORPAY_KEY_SECRET!,
})

// Platform fee rates by role
const PLATFORM_FEE: Record<string, number> = {
  FREELANCER:    0.10, // 10%
  ONSITE_WORKER: 0.08, // 8%
  ENTERPRISE:    0.05, // 5% custom
}

export const paymentService = {

  // ── CREATE STRIPE PAYMENT INTENT (escrow) ──────────────────────────────────
  async createEscrow(jobId: string, amountUSD: number, payerId: string): Promise<string> {
    const job     = await db.job.findUniqueOrThrow({ where: { id: jobId } })
    const roleKey = job.type === 'FREELANCE' ? 'FREELANCER' : 'ONSITE_WORKER'
    const fee     = Math.round(amountUSD * PLATFORM_FEE[roleKey] * 100) // in cents
    const amount  = Math.round(amountUSD * 100)

    const pi = await stripe.paymentIntents.create({
      amount,
      currency:       'usd',
      capture_method: 'manual',       // ← key for escrow behaviour
      metadata:       { jobId, payerId },
      application_fee_amount: fee,
    })

    await db.payment.create({
      data: {
        jobId,
        payerId,
        amount:       amountUSD,
        currency:     'USD',
        platformFee:  amountUSD * PLATFORM_FEE[roleKey],
        netAmount:    amountUSD * (1 - PLATFORM_FEE[roleKey]),
        provider:     'STRIPE',
        status:       'AUTHORIZED',
        stripePaymentIntentId: pi.id,
      },
    })

    return pi.client_secret!
  },

  // ── RELEASE ESCROW (client approves work) ──────────────────────────────────
  async releaseEscrow(paymentId: string): Promise<void> {
    const payment = await db.payment.findUniqueOrThrow({ where: { id: paymentId }, include: { job: true } })
    if (payment.status !== 'AUTHORIZED') throw new Error('Payment not in authorized state')

    // Capture the PaymentIntent
    await stripe.paymentIntents.capture(payment.stripePaymentIntentId!)

    // Credit worker/freelancer wallet
    const recipientId = payment.job.hiredFreelancerId ?? payment.job.hiredWorkerId
    if (recipientId) {
      await db.wallet.update({
        where: { userId: recipientId },
        data:  { balance: { increment: payment.netAmount } },
      })
      await db.walletTransaction.create({
        data: {
          wallet:      { connect: { userId: recipientId } },
          amount:      payment.netAmount,
          type:        'credit',
          description: `Payment for job: ${payment.job.title}`,
          reference:   payment.stripePaymentIntentId ?? undefined,
        },
      })
    }

    await db.payment.update({
      where: { id: paymentId },
      data:  { status: 'RELEASED', escrowReleased: true, releasedAt: new Date() },
    })
  },

  // ── REVEAL WORKER PHOTO AFTER PAYMENT ──────────────────────────────────────
  async authorizeAndRevealPhoto(jobId: string, amountUSD: number, payerId: string): Promise<{ clientSecret: string }> {
    const clientSecret = await this.createEscrow(jobId, amountUSD, payerId)

    // Mark photo as visible once payment is authorized
    const job = await db.job.findUnique({ where: { id: jobId } })
    if (job?.hiredWorkerId) {
      await db.onsiteWorkerProfile.update({
        where: { userId: job.hiredWorkerId },
        data:  { photoVisible: true },
      })
    }

    await db.payment.updateMany({
      where: { jobId },
      data:  { photoUnlocked: true },
    })

    return { clientSecret }
  },

  // ── RAZORPAY ORDER (India / UPI) ───────────────────────────────────────────
  async createRazorpayOrder(jobId: string, amountINR: number, payerId: string) {
    const order = await razorpay.orders.create({
      amount:   Math.round(amountINR * 100), // paise
      currency: 'INR',
      notes:    { jobId, payerId },
    })

    await db.payment.create({
      data: {
        jobId,
        payerId,
        amount:      amountINR,
        currency:    'INR',
        platformFee: amountINR * 0.08,
        netAmount:   amountINR * 0.92,
        provider:    'RAZORPAY',
        status:      'PENDING',
        razorpayOrderId: order.id,
      },
    })

    return order
  },

  // ── VERIFY RAZORPAY PAYMENT ────────────────────────────────────────────────
  async verifyRazorpay(orderId: string, paymentId: string, signature: string): Promise<boolean> {
    const crypto = await import('crypto')
    const expected = crypto
      .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET!)
      .update(`${orderId}|${paymentId}`)
      .digest('hex')
    return expected === signature
  },

  // ── WALLET WITHDRAWAL ──────────────────────────────────────────────────────
  async requestWithdrawal(userId: string, amountUSD: number): Promise<void> {
    const wallet = await db.wallet.findUniqueOrThrow({ where: { userId } })
    if (wallet.balance.lessThan(amountUSD)) throw new Error('Insufficient wallet balance')

    // Deduct immediately, transfer via Stripe Connect
    await db.wallet.update({
      where: { userId },
      data:  { balance: { decrement: amountUSD } },
    })

    await db.walletTransaction.create({
      data: {
        wallet:      { connect: { userId } },
        amount:      -amountUSD,
        type:        'withdrawal',
        description: 'Withdrawal to bank account',
      },
    })

    // Queue Stripe payout (processed async)
    const { withdrawalQueue } = await import('../jobs/queues')
    await withdrawalQueue.add('process-withdrawal', { userId, amountUSD })
  },

  // ── REFUND ────────────────────────────────────────────────────────────────
  async refund(paymentId: string, reason: string): Promise<void> {
    const payment = await db.payment.findUniqueOrThrow({ where: { id: paymentId } })

    if (payment.provider === 'STRIPE' && payment.stripePaymentIntentId) {
      await stripe.paymentIntents.cancel(payment.stripePaymentIntentId)
    }

    await db.payment.update({
      where: { id: paymentId },
      data:  { status: 'REFUNDED', refundedAt: new Date(), refundReason: reason },
    })
  },
}

// ── STRIPE WEBHOOK HANDLER ────────────────────────────────────────────────────
export async function handleStripeWebhook(rawBody: Buffer, signature: string): Promise<void> {
  const event = stripe.webhooks.constructEvent(rawBody, signature, process.env.STRIPE_WEBHOOK_SECRET!)

  switch (event.type) {
    case 'payment_intent.succeeded': {
      const pi = event.data.object as Stripe.PaymentIntent
      await db.payment.updateMany({
        where: { stripePaymentIntentId: pi.id },
        data:  { status: 'CAPTURED' },
      })
      break
    }
    case 'payment_intent.payment_failed': {
      const pi = event.data.object as Stripe.PaymentIntent
      await db.payment.updateMany({
        where: { stripePaymentIntentId: pi.id },
        data:  { status: 'FAILED' },
      })
      break
    }
    case 'transfer.created': {
      // Stripe Connect transfer — log it
      console.log('Stripe transfer created:', event.data.object)
      break
    }
  }
}
