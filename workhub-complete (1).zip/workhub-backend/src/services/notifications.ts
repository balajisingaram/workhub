import { db } from '../lib/db'

export const notifyService = {
  async create(data: { userId: string; type: any; title: string; body: string; link?: string }) {
    return db.notification.create({ data })
  },
  async markRead(id: string) {
    return db.notification.update({ where: { id }, data: { isRead: true } })
  },
}
