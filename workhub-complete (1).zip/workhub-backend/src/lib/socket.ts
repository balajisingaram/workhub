import { Server, Socket } from 'socket.io'
import jwt from 'jsonwebtoken'
import { db } from './db'

interface AuthSocket extends Socket {
  userId?: string
  userRole?: string
}

// Track online users: userId → socketId
const onlineUsers = new Map<string, string>()

export function registerSocketHandlers(io: Server) {

  // ── AUTH MIDDLEWARE ─────────────────────────────────────────────────────────
  io.use((socket: AuthSocket, next) => {
    const token = socket.handshake.auth?.token
    if (!token) return next(new Error('Missing auth token'))
    try {
      const payload = jwt.verify(token, process.env.JWT_SECRET!) as any
      socket.userId   = payload.id
      socket.userRole = payload.role
      next()
    } catch {
      next(new Error('Invalid token'))
    }
  })

  io.on('connection', (socket: AuthSocket) => {
    const userId = socket.userId!
    onlineUsers.set(userId, socket.id)

    // Update online status
    db.freelancerProfile.updateMany({ where: { userId }, data: { isOnline: true } }).catch(() => {})
    db.onsiteWorkerProfile.updateMany({ where: { userId }, data: { isOnline: true } }).catch(() => {})

    console.log(`[Socket] ${userId} connected (${socket.userRole})`)

    // ── JOIN JOB ROOM ─────────────────────────────────────────────────────────
    socket.on('join:job', (jobId: string) => {
      socket.join(`job:${jobId}`)
    })

    socket.on('leave:job', (jobId: string) => {
      socket.leave(`job:${jobId}`)
    })

    // ── SEND MESSAGE ──────────────────────────────────────────────────────────
    socket.on('message:send', async (data: { jobId: string; content: string; fileUrl?: string; fileType?: string }) => {
      try {
        const message = await db.message.create({
          data: {
            jobId:    data.jobId,
            senderId: userId,
            content:  data.content,
            fileUrl:  data.fileUrl,
            fileType: data.fileType,
          },
          include: { sender: { select: { id: true, email: true, role: true } } },
        })

        // Broadcast to everyone in the job room
        io.to(`job:${data.jobId}`).emit('message:new', message)

        // Notify recipient if offline
        const job = await db.job.findUnique({ where: { id: data.jobId } })
        const recipientId = userId === job?.clientId ? job?.hiredFreelancerId : job?.clientId
        if (recipientId && !onlineUsers.has(recipientId)) {
          await db.notification.create({
            data: {
              userId:  recipientId,
              type:    'MESSAGE_RECEIVED',
              title:   'New message',
              body:    data.content.slice(0, 80),
              link:    `/dashboard/messages/${data.jobId}`,
            },
          })
        }
      } catch (err) {
        socket.emit('error', { message: 'Failed to send message' })
      }
    })

    // ── TYPING INDICATOR ──────────────────────────────────────────────────────
    socket.on('typing:start', (jobId: string) => {
      socket.to(`job:${jobId}`).emit('typing:start', { userId })
    })

    socket.on('typing:stop', (jobId: string) => {
      socket.to(`job:${jobId}`).emit('typing:stop', { userId })
    })

    // ── MARK MESSAGES READ ────────────────────────────────────────────────────
    socket.on('messages:read', async (jobId: string) => {
      await db.message.updateMany({
        where: { jobId, senderId: { not: userId }, isRead: false },
        data:  { isRead: true },
      })
      socket.to(`job:${jobId}`).emit('messages:read', { readBy: userId })
    })

    // ── GPS CHECK-IN (onsite workers) ─────────────────────────────────────────
    socket.on('worker:checkin', async (data: { jobId: string; lat: number; lng: number; method: string }) => {
      try {
        // Verify distance from job site
        const job = await db.job.findUnique({ where: { id: data.jobId } })
        if (!job?.locationLat || !job?.locationLng) {
          return socket.emit('checkin:error', { message: 'Job has no location set' })
        }

        const distanceM = haversineMetres(
          data.lat, data.lng,
          Number(job.locationLat), Number(job.locationLng)
        )

        const MAX_DISTANCE = 500 // metres
        const verified = distanceM <= MAX_DISTANCE

        const profile = await db.onsiteWorkerProfile.findUnique({ where: { userId } })
        if (!profile) return socket.emit('checkin:error', { message: 'Worker profile not found' })

        const checkIn = await db.checkIn.create({
          data: {
            workerId:  profile.id,
            jobId:     data.jobId,
            lat:       data.lat,
            lng:       data.lng,
            distanceM: Math.round(distanceM),
            verified,
            method:    data.method,
          },
        })

        socket.emit('checkin:result', { verified, distanceM: Math.round(distanceM), checkIn })

        if (verified) {
          // Notify client
          await db.notification.create({
            data: {
              userId: job.clientId,
              type:   'CHECKIN_VERIFIED',
              title:  'Worker checked in',
              body:   `Your worker has arrived and checked in (${Math.round(distanceM)}m from site).`,
              link:   `/dashboard/jobs/${data.jobId}`,
            },
          })
          const clientSocketId = onlineUsers.get(job.clientId)
          if (clientSocketId) io.to(clientSocketId).emit('worker:arrived', { jobId: data.jobId, distanceM })
        }
      } catch (err) {
        socket.emit('checkin:error', { message: 'Check-in failed' })
      }
    })

    // ── REAL-TIME NOTIFICATION ────────────────────────────────────────────────
    socket.on('notification:read', async (notificationId: string) => {
      await db.notification.updateMany({
        where: { id: notificationId, userId },
        data:  { isRead: true },
      })
    })

    // ── DISCONNECT ────────────────────────────────────────────────────────────
    socket.on('disconnect', () => {
      onlineUsers.delete(userId)
      db.freelancerProfile.updateMany({ where: { userId }, data: { isOnline: false } }).catch(() => {})
      db.onsiteWorkerProfile.updateMany({ where: { userId }, data: { isOnline: false } }).catch(() => {})
      console.log(`[Socket] ${userId} disconnected`)
    })
  })
}

// ── PUSH NOTIFICATION FROM SERVER ────────────────────────────────────────────
export function pushToUser(io: Server, userId: string, event: string, data: any) {
  const socketId = onlineUsers.get(userId)
  if (socketId) io.to(socketId).emit(event, data)
}

// ── HAVERSINE DISTANCE ────────────────────────────────────────────────────────
function haversineMetres(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R  = 6_371_000
  const φ1 = lat1 * Math.PI / 180
  const φ2 = lat2 * Math.PI / 180
  const Δφ = (lat2 - lat1) * Math.PI / 180
  const Δλ = (lng2 - lng1) * Math.PI / 180
  const a  = Math.sin(Δφ/2)**2 + Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ/2)**2
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
}
