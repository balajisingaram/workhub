// ── payments.ts ───────────────────────────────────────────────────────────────
import { Router as PayRouter } from 'express'
import { paymentService } from '../services/payment'
import { AuthRequest } from '../middleware/auth'
import { db } from '../lib/db'

export const paymentsRouter = PayRouter()

paymentsRouter.post('/escrow', async (req: AuthRequest, res, next) => {
  try {
    const { jobId, amountUSD } = req.body
    const clientSecret = await paymentService.createEscrow(jobId, amountUSD, req.user!.id)
    res.json({ clientSecret })
  } catch (err) { next(err) }
})

paymentsRouter.post('/reveal-worker', async (req: AuthRequest, res, next) => {
  try {
    const { jobId, amountUSD } = req.body
    const result = await paymentService.authorizeAndRevealPhoto(jobId, amountUSD, req.user!.id)
    res.json(result)
  } catch (err) { next(err) }
})

paymentsRouter.get('/wallet', async (req: AuthRequest, res, next) => {
  try {
    const wallet = await db.wallet.findUnique({
      where:   { userId: req.user!.id },
      include: { transactions: { orderBy: { createdAt: 'desc' }, take: 20 } },
    })
    res.json({ wallet })
  } catch (err) { next(err) }
})

paymentsRouter.post('/withdraw', async (req: AuthRequest, res, next) => {
  try {
    await paymentService.requestWithdrawal(req.user!.id, req.body.amountUSD)
    res.json({ message: 'Withdrawal queued — arrives in 1–2 business days' })
  } catch (err) { next(err) }
})

paymentsRouter.post('/razorpay/order', async (req: AuthRequest, res, next) => {
  try {
    const order = await paymentService.createRazorpayOrder(req.body.jobId, req.body.amountINR, req.user!.id)
    res.json({ order })
  } catch (err) { next(err) }
})
