export { shiftsRouter as default } from './all-routes'
