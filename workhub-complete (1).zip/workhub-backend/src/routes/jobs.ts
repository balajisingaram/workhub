import { Router } from 'express'
import { z } from 'zod'
import { db } from '../lib/db'
import { authMiddleware, optionalAuth, requireClient, AuthRequest } from '../middleware/auth'
import { validate } from '../middleware/validate'
import { notifyService } from '../services/notifications'

const router = Router()

// ── LIST JOBS (public, with filters) ─────────────────────────────────────────
router.get('/', optionalAuth, async (req: AuthRequest, res, next) => {
  try {
    const { type, category, status, skills, search, page = '1', limit = '20' } = req.query
    const skip = (parseInt(page as string) - 1) * parseInt(limit as string)

    const where: any = {}
    if (type)     where.type     = type
    if (category) where.category = category
    if (status)   where.status   = status
    else          where.status   = 'OPEN'
    if (skills)   where.skills   = { hasSome: (skills as string).split(',') }
    if (search)   where.title    = { contains: search as string, mode: 'insensitive' }

    const [jobs, total] = await Promise.all([
      db.job.findMany({
        where,
        skip,
        take: parseInt(limit as string),
        orderBy: [{ isUrgent: 'desc' }, { createdAt: 'desc' }],
        include: {
          client: { select: { id: true, email: true } },
          _count: { select: { proposals: true } },
        },
      }),
      db.job.count({ where }),
    ])

    res.json({ jobs, total, page: parseInt(page as string), pages: Math.ceil(total / parseInt(limit as string)) })
  } catch (err) { next(err) }
})

// ── GET SINGLE JOB ────────────────────────────────────────────────────────────
router.get('/:id', optionalAuth, async (req, res, next) => {
  try {
    const job = await db.job.findUnique({
      where: { id: req.params.id },
      include: {
        client: { select: { id: true, email: true } },
        milestones: true,
        _count: { select: { proposals: true } },
      },
    })
    if (!job) return res.status(404).json({ error: 'Job not found' })
    res.json({ job })
  } catch (err) { next(err) }
})

// ── CREATE JOB ────────────────────────────────────────────────────────────────
const CreateJobSchema = z.object({
  type:          z.enum(['FREELANCE', 'ONSITE', 'STAFFING']),
  title:         z.string().min(5).max(200),
  description:   z.string().min(20),
  category:      z.string().optional(),
  skills:        z.array(z.string()).optional(),
  budgetMin:     z.number().positive(),
  budgetMax:     z.number().positive(),
  budgetType:    z.enum(['FIXED', 'HOURLY']).default('FIXED'),
  weightTierReq: z.enum(['LIGHT', 'MEDIUM', 'HEAVY', 'EXTREME']).optional(),
  locationLabel: z.string().optional(),
  locationLat:   z.number().optional(),
  locationLng:   z.number().optional(),
  jobDate:       z.string().optional(),
  hoursNeeded:   z.number().optional(),
  deadline:      z.string().optional(),
  isUrgent:      z.boolean().default(false),
})

router.post('/', authMiddleware, requireClient, validate(CreateJobSchema), async (req: AuthRequest, res, next) => {
  try {
    const job = await db.job.create({
      data: {
        ...req.body,
        clientId:  req.user!.id,
        jobDate:   req.body.jobDate  ? new Date(req.body.jobDate)  : undefined,
        deadline:  req.body.deadline ? new Date(req.body.deadline) : undefined,
        budgetMin: req.body.budgetMin,
        budgetMax: req.body.budgetMax,
      },
    })

    // If onsite job — trigger worker matching
    if (job.type === 'ONSITE' && job.locationLat && job.locationLng) {
      await matchOnsiteWorkers(job)
    }

    res.status(201).json({ job })
  } catch (err) { next(err) }
})

// ── UPDATE JOB ────────────────────────────────────────────────────────────────
router.patch('/:id', authMiddleware, async (req: AuthRequest, res, next) => {
  try {
    const job = await db.job.findUnique({ where: { id: req.params.id } })
    if (!job) return res.status(404).json({ error: 'Job not found' })
    if (job.clientId !== req.user!.id && req.user!.role !== 'ADMIN') {
      return res.status(403).json({ error: 'Not authorized' })
    }

    const updated = await db.job.update({
      where: { id: req.params.id },
      data:  req.body,
    })
    res.json({ job: updated })
  } catch (err) { next(err) }
})

// ── COMPLETE JOB (triggers escrow release) ────────────────────────────────────
router.post('/:id/complete', authMiddleware, requireClient, async (req: AuthRequest, res, next) => {
  try {
    const job = await db.job.findUnique({ where: { id: req.params.id }, include: { payment: true } })
    if (!job) return res.status(404).json({ error: 'Job not found' })
    if (job.clientId !== req.user!.id) return res.status(403).json({ error: 'Not authorized' })

    await db.job.update({ where: { id: req.params.id }, data: { status: 'COMPLETED', completedAt: new Date() } })

    // Trigger payment release via payment service
    if (job.payment?.id) {
      const { paymentService } = await import('../services/payment')
      await paymentService.releaseEscrow(job.payment.id)
    }

    await notifyService.create({
      userId: job.hiredFreelancerId ?? job.hiredWorkerId ?? req.user!.id,
      type:   'PAYMENT_RELEASED',
      title:  'Payment released!',
      body:   `Your payment for "${job.title}" has been released to your wallet.`,
    })

    res.json({ message: 'Job completed — escrow released' })
  } catch (err) { next(err) }
})

// ── GPS WORKER MATCHING ───────────────────────────────────────────────────────
async function matchOnsiteWorkers(job: any) {
  const radiusMetres = 50_000 // 50km default

  // PostGIS ST_DWithin query
  const workers = await db.$queryRaw<any[]>`
    SELECT owp.id, owp."workerCode", owp."weightTier", owp."radiusKm",
           u.email,
           ST_Distance(
             ST_Point(owp."locationLng"::float8, owp."locationLat"::float8)::geography,
             ST_Point(${job.locationLng}::float8, ${job.locationLat}::float8)::geography
           ) AS distance_m
    FROM   onsite_worker_profiles owp
    JOIN   users u ON u.id = owp."userId"
    WHERE  owp."isVerified" = true
      AND  owp."isOnline"   = true
      AND  owp."weightTier" = ${job.weightTierReq ?? 'LIGHT'}
      AND  ST_DWithin(
             ST_Point(owp."locationLng"::float8, owp."locationLat"::float8)::geography,
             ST_Point(${job.locationLng}::float8, ${job.locationLat}::float8)::geography,
             ${radiusMetres}
           )
    ORDER  BY distance_m ASC
    LIMIT  20
  `

  // Notify matched workers
  for (const worker of workers) {
    await notifyService.create({
      userId: worker.userId,
      type:   'JOB_POSTED',
      title:  'New job near you!',
      body:   `A new ${job.weightTierReq?.toLowerCase()} duty job is available ${Math.round(worker.distance_m / 1000)}km away.`,
      link:   `/onsite/jobs/${job.id}`,
    })
  }

  return workers
}

export default router
