export { proposalsRouter as default } from './all-routes'
