import { Router } from 'express'
import { db } from '../lib/db'
import { AuthRequest, requireAdmin } from '../middleware/auth'
import { publicUpload, privateUpload, getPresignedUrl } from '../services/storage'
import { z } from 'zod'
import { validate } from '../middleware/validate'

// ══════════════════════════════════════════════════════════════════════════════
// MESSAGES
// ══════════════════════════════════════════════════════════════════════════════
export const messagesRouter = Router()

messagesRouter.get('/job/:jobId', async (req: AuthRequest, res, next) => {
  try {
    const messages = await db.message.findMany({
      where:   { jobId: req.params.jobId },
      orderBy: { createdAt: 'asc' },
      include: { sender: { select: { id: true, email: true, role: true } } },
    })
    res.json({ messages })
  } catch (err) { next(err) }
})

// ══════════════════════════════════════════════════════════════════════════════
// FREELANCERS (public browse + profile update)
// ══════════════════════════════════════════════════════════════════════════════
export const freelancersRouter = Router()

freelancersRouter.get('/', async (req, res, next) => {
  try {
    const { search, skills, minRate, maxRate, location, page = '1', limit = '20', sort = 'rank' } = req.query
    const skip = (parseInt(page as string) - 1) * parseInt(limit as string)
    const where: any = {}
    if (search)  where.OR = [
      { title:    { contains: search as string, mode: 'insensitive' } },
      { bio:      { contains: search as string, mode: 'insensitive' } },
    ]
    if (minRate) where.hourlyRateMin = { gte: parseInt(minRate as string) }
    if (maxRate) where.hourlyRateMax = { lte: parseInt(maxRate as string) }
    if (location) where.location = { contains: location as string, mode: 'insensitive' }

    const orderBy: any = sort === 'rating' ? { avgRating: 'desc' }
      : sort === 'jobs'   ? { jobsCompleted: 'desc' }
      : sort === 'rate'   ? { hourlyRateMin: 'asc' }
      : { searchRank: 'desc' }

    const [profiles, total] = await Promise.all([
      db.freelancerProfile.findMany({
        where, skip, take: parseInt(limit as string), orderBy,
        include: { skills: true, user: { select: { id: true, status: true, kycVerified: true } } },
      }),
      db.freelancerProfile.count({ where }),
    ])
    res.json({ profiles, total })
  } catch (err) { next(err) }
})

freelancersRouter.get('/:id', async (req, res, next) => {
  try {
    const profile = await db.freelancerProfile.findUnique({
      where:   { id: req.params.id },
      include: { skills: true, services: true, education: true, experience: true,
                 user: { select: { id: true, kycVerified: true, createdAt: true } } },
    })
    if (!profile) return res.status(404).json({ error: 'Profile not found' })
    res.json({ profile })
  } catch (err) { next(err) }
})

freelancersRouter.patch('/me', async (req: AuthRequest, res, next) => {
  try {
    const profile = await db.freelancerProfile.update({
      where: { userId: req.user!.id },
      data:  req.body,
    })
    res.json({ profile })
  } catch (err) { next(err) }
})

// ══════════════════════════════════════════════════════════════════════════════
// ONSITE WORKERS
// ══════════════════════════════════════════════════════════════════════════════
export const workersRouter = Router()

workersRouter.get('/', async (req, res, next) => {
  try {
    const { tier, lat, lng, radius = '50', page = '1', limit = '20' } = req.query

    if (lat && lng) {
      // PostGIS spatial query
      const workers = await db.$queryRaw<any[]>`
        SELECT owp.*, u.id as "userId", u.status,
          ST_Distance(
            ST_Point(owp."locationLng"::float8, owp."locationLat"::float8)::geography,
            ST_Point(${parseFloat(lng as string)}::float8, ${parseFloat(lat as string)}::float8)::geography
          ) AS distance_m
        FROM   onsite_worker_profiles owp
        JOIN   users u ON u.id = owp."userId"
        WHERE  owp."isVerified" = true
          AND  owp."isOnline"   = true
          ${tier ? db.$queryRaw`AND owp."weightTier" = ${tier}` : db.$queryRaw``}
          AND  ST_DWithin(
                 ST_Point(owp."locationLng"::float8, owp."locationLat"::float8)::geography,
                 ST_Point(${parseFloat(lng as string)}::float8, ${parseFloat(lat as string)}::float8)::geography,
                 ${parseFloat(radius as string) * 1000}
               )
        ORDER  BY distance_m ASC
        LIMIT  ${parseInt(limit as string)}
        OFFSET ${(parseInt(page as string) - 1) * parseInt(limit as string)}
      `
      // Strip private photo URL from response
      const safe = workers.map(w => ({ ...w, photoUrl: w.photoVisible ? w.photoUrl : null }))
      return res.json({ workers: safe })
    }

    const where: any = { isVerified: true }
    if (tier) where.weightTier = tier
    const workers = await db.onsiteWorkerProfile.findMany({
      where, take: parseInt(limit as string),
      skip: (parseInt(page as string) - 1) * parseInt(limit as string),
    })
    const safe = workers.map(w => ({ ...w, photoUrl: w.photoVisible ? w.photoUrl : null }))
    res.json({ workers: safe })
  } catch (err) { next(err) }
})

// Return presigned photo URL only if payment confirmed
workersRouter.get('/:id/photo', async (req: AuthRequest, res, next) => {
  try {
    const worker = await db.onsiteWorkerProfile.findUnique({ where: { id: req.params.id } })
    if (!worker) return res.status(404).json({ error: 'Worker not found' })
    if (!worker.photoVisible || !worker.photoUrl) {
      return res.status(403).json({ error: 'Photo locked — complete payment to reveal' })
    }
    const url = await getPresignedUrl(worker.photoUrl, 900) // 15-min URL
    res.json({ url })
  } catch (err) { next(err) }
})

workersRouter.patch('/me', async (req: AuthRequest, res, next) => {
  try {
    const profile = await db.onsiteWorkerProfile.update({
      where: { userId: req.user!.id },
      data:  req.body,
    })
    res.json({ profile })
  } catch (err) { next(err) }
})

// ══════════════════════════════════════════════════════════════════════════════
// PROPOSALS
// ══════════════════════════════════════════════════════════════════════════════
export const proposalsRouter = Router()

proposalsRouter.post('/', async (req: AuthRequest, res, next) => {
  try {
    const { jobId, coverLetter, rate, deliveryDays } = req.body
    const proposal = await db.proposal.create({
      data: { jobId, freelancerId: req.user!.id, coverLetter, rate, deliveryDays },
    })
    await db.job.update({ where: { id: jobId }, data: { proposalCount: { increment: 1 } } })
    res.status(201).json({ proposal })
  } catch (err) { next(err) }
})

proposalsRouter.get('/job/:jobId', async (req: AuthRequest, res, next) => {
  try {
    const proposals = await db.proposal.findMany({
      where:   { jobId: req.params.jobId },
      include: { freelancer: { select: { id: true, email: true } } },
      orderBy: { createdAt: 'desc' },
    })
    res.json({ proposals })
  } catch (err) { next(err) }
})

proposalsRouter.patch('/:id/accept', async (req: AuthRequest, res, next) => {
  try {
    const proposal = await db.proposal.update({
      where: { id: req.params.id },
      data:  { status: 'ACCEPTED' },
    })
    await db.job.update({
      where: { id: proposal.jobId },
      data:  { status: 'ASSIGNED', hiredFreelancerId: proposal.freelancerId },
    })
    // Decline all other proposals
    await db.proposal.updateMany({
      where: { jobId: proposal.jobId, id: { not: req.params.id } },
      data:  { status: 'DECLINED' },
    })
    res.json({ proposal })
  } catch (err) { next(err) }
})

// ══════════════════════════════════════════════════════════════════════════════
// REVIEWS
// ══════════════════════════════════════════════════════════════════════════════
export const reviewsRouter = Router()

reviewsRouter.post('/', async (req: AuthRequest, res, next) => {
  try {
    const { jobId, subjectId, rating, comment } = req.body
    const review = await db.review.create({
      data: { jobId, authorId: req.user!.id, subjectId, rating, comment },
    })
    // Update avg rating on profile
    const avg = await db.review.aggregate({ where: { subjectId }, _avg: { rating: true }, _count: true })
    await db.freelancerProfile.updateMany({
      where: { userId: subjectId },
      data:  { avgRating: avg._avg.rating ?? 0, reviewCount: avg._count },
    })
    await db.onsiteWorkerProfile.updateMany({
      where: { userId: subjectId },
      data:  { avgRating: avg._avg.rating ?? 0, reviewCount: avg._count },
    })
    res.status(201).json({ review })
  } catch (err) { next(err) }
})

// ══════════════════════════════════════════════════════════════════════════════
// NOTIFICATIONS
// ══════════════════════════════════════════════════════════════════════════════
export const notificationsRouter = Router()

notificationsRouter.get('/', async (req: AuthRequest, res, next) => {
  try {
    const notifications = await db.notification.findMany({
      where:   { userId: req.user!.id },
      orderBy: { createdAt: 'desc' },
      take:    50,
    })
    const unread = notifications.filter(n => !n.isRead).length
    res.json({ notifications, unread })
  } catch (err) { next(err) }
})

notificationsRouter.patch('/:id/read', async (req: AuthRequest, res, next) => {
  try {
    await db.notification.updateMany({ where: { id: req.params.id, userId: req.user!.id }, data: { isRead: true } })
    res.json({ ok: true })
  } catch (err) { next(err) }
})

notificationsRouter.patch('/read-all', async (req: AuthRequest, res, next) => {
  try {
    await db.notification.updateMany({ where: { userId: req.user!.id, isRead: false }, data: { isRead: true } })
    res.json({ ok: true })
  } catch (err) { next(err) }
})

// ══════════════════════════════════════════════════════════════════════════════
// FILE UPLOAD
// ══════════════════════════════════════════════════════════════════════════════
export const uploadRouter = Router()

uploadRouter.post('/avatar', publicUpload.single('file'), async (req: AuthRequest, res, next) => {
  try {
    const file = req.file as any
    if (!file) return res.status(400).json({ error: 'No file provided' })
    await db.freelancerProfile.updateMany({ where: { userId: req.user!.id }, data: { avatarUrl: file.location } })
    res.json({ url: file.location })
  } catch (err) { next(err) }
})

uploadRouter.post('/portfolio', publicUpload.array('files', 10), async (req: AuthRequest, res, next) => {
  try {
    const files = (req.files as any[]) ?? []
    const urls  = files.map(f => f.location)
    await db.freelancerProfile.updateMany({ where: { userId: req.user!.id }, data: { portfolioUrls: { push: urls } } })
    res.json({ urls })
  } catch (err) { next(err) }
})

uploadRouter.post('/worker-photo', privateUpload.single('file'), async (req: AuthRequest, res, next) => {
  try {
    const file = req.file as any
    if (!file) return res.status(400).json({ error: 'No file provided' })
    await db.onsiteWorkerProfile.updateMany({ where: { userId: req.user!.id }, data: { photoUrl: file.key } })
    res.json({ key: file.key })
  } catch (err) { next(err) }
})

uploadRouter.post('/id-document', privateUpload.single('file'), async (req: AuthRequest, res, next) => {
  try {
    const file = req.file as any
    if (!file) return res.status(400).json({ error: 'No file provided' })
    // In production: trigger Onfido KYC check
    res.json({ key: file.key, message: 'Document submitted for KYC verification' })
  } catch (err) { next(err) }
})

// ══════════════════════════════════════════════════════════════════════════════
// USERS
// ══════════════════════════════════════════════════════════════════════════════
export const usersRouter = Router()

usersRouter.get('/me', async (req: AuthRequest, res, next) => {
  try {
    const user = await db.user.findUnique({
      where:   { id: req.user!.id },
      include: { freelancerProfile: { include: { skills: true } }, onsiteWorkerProfile: true, enterprise: true, wallet: true },
      omit:    { passwordHash: true },
    })
    res.json({ user })
  } catch (err) { next(err) }
})

usersRouter.patch('/me', async (req: AuthRequest, res, next) => {
  try {
    const allowed = ['email']
    const data: any = {}
    for (const k of allowed) if (req.body[k] !== undefined) data[k] = req.body[k]
    const user = await db.user.update({ where: { id: req.user!.id }, data })
    res.json({ user })
  } catch (err) { next(err) }
})

// ══════════════════════════════════════════════════════════════════════════════
// SHIFTS
// ══════════════════════════════════════════════════════════════════════════════
export const shiftsRouter = Router()

shiftsRouter.get('/', async (req: AuthRequest, res, next) => {
  try {
    const ent = await db.enterprise.findUnique({ where: { userId: req.user!.id } })
    if (!ent) return res.status(403).json({ error: 'Enterprise only' })
    const shifts = await db.shift.findMany({
      where:   { enterpriseId: ent.id },
      include: { assignments: { include: { employee: true } } },
      orderBy: { date: 'asc' },
    })
    res.json({ shifts })
  } catch (err) { next(err) }
})

shiftsRouter.post('/', async (req: AuthRequest, res, next) => {
  try {
    const ent = await db.enterprise.findUnique({ where: { userId: req.user!.id } })
    if (!ent) return res.status(403).json({ error: 'Enterprise only' })
    const shift = await db.shift.create({ data: { ...req.body, enterpriseId: ent.id, date: new Date(req.body.date) } })
    res.status(201).json({ shift })
  } catch (err) { next(err) }
})

shiftsRouter.post('/:id/assign', async (req: AuthRequest, res, next) => {
  try {
    const { employeeIds } = req.body as { employeeIds: string[] }
    const assignments = await Promise.all(
      employeeIds.map(employeeId =>
        db.shiftAssignment.upsert({
          where:  { shiftId_employeeId: { shiftId: req.params.id, employeeId } },
          create: { shiftId: req.params.id, employeeId },
          update: {},
        })
      )
    )
    // Queue notification emails
    const shift = await db.shift.findUnique({ where: { id: req.params.id } })
    const { emailQueue } = await import('../jobs/queues')
    for (const empId of employeeIds) {
      const emp = await db.employee.findUnique({ where: { id: empId } })
      if (emp && shift) {
        await emailQueue.add('send', {
          type: 'shift-assignment', to: emp.email, name: emp.name,
          shiftTitle: shift.title, shiftDate: shift.date.toISOString(),
          enterpriseId: shift.enterpriseId,
        })
      }
    }
    res.json({ assignments })
  } catch (err) { next(err) }
})

// ══════════════════════════════════════════════════════════════════════════════
// ADMIN
// ══════════════════════════════════════════════════════════════════════════════
export const adminRouter = Router()
adminRouter.use(requireAdmin)

adminRouter.get('/stats', async (_req, res, next) => {
  try {
    const [users, jobs, payments, disputes] = await Promise.all([
      db.user.count(),
      db.job.count(),
      db.payment.aggregate({ _sum: { platformFee: true }, where: { status: { in: ['CAPTURED','RELEASED'] } } }),
      db.dispute.count({ where: { status: 'OPEN' } }),
    ])
    res.json({ users, jobs, platformRevenue: payments._sum.platformFee ?? 0, openDisputes: disputes })
  } catch (err) { next(err) }
})

adminRouter.get('/users', async (req, res, next) => {
  try {
    const { role, status, page = '1', limit = '50' } = req.query
    const skip  = (parseInt(page as string) - 1) * parseInt(limit as string)
    const where: any = {}
    if (role)   where.role   = role
    if (status) where.status = status
    const [users, total] = await Promise.all([
      db.user.findMany({ where, skip, take: parseInt(limit as string), orderBy: { createdAt: 'desc' },
        select: { id: true, email: true, role: true, status: true, kycVerified: true, createdAt: true, lastLoginAt: true } }),
      db.user.count({ where }),
    ])
    res.json({ users, total })
  } catch (err) { next(err) }
})

adminRouter.patch('/users/:id/suspend', async (req, res, next) => {
  try {
    await db.user.update({ where: { id: req.params.id }, data: { status: 'SUSPENDED' } })
    res.json({ message: 'User suspended' })
  } catch (err) { next(err) }
})

adminRouter.patch('/users/:id/kyc-approve', async (req, res, next) => {
  try {
    await db.user.update({ where: { id: req.params.id }, data: { kycVerified: true, status: 'ACTIVE' } })
    await db.onsiteWorkerProfile.updateMany({ where: { userId: req.params.id }, data: { isVerified: true } })
    res.json({ message: 'KYC approved' })
  } catch (err) { next(err) }
})

adminRouter.get('/disputes', async (_req, res, next) => {
  try {
    const disputes = await db.dispute.findMany({
      where:   { status: { in: ['OPEN','UNDER_REVIEW'] } },
      orderBy: { createdAt: 'desc' },
    })
    res.json({ disputes })
  } catch (err) { next(err) }
})

adminRouter.patch('/disputes/:id/resolve', async (req, res, next) => {
  try {
    const { resolution, releaseToFreelancer } = req.body
    await db.dispute.update({
      where: { id: req.params.id },
      data:  { status: 'RESOLVED', resolution, resolvedAt: new Date() },
    })
    if (releaseToFreelancer) {
      const dispute = await db.dispute.findUnique({ where: { id: req.params.id } })
      if (dispute) {
        const payment = await db.payment.findUnique({ where: { jobId: dispute.jobId } })
        if (payment) await paymentService.releaseEscrow(payment.id)
      }
    }
    res.json({ message: 'Dispute resolved' })
  } catch (err) { next(err) }
})

import { paymentService } from '../services/payment'
