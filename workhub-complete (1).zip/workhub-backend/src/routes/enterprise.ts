import { Router } from 'express'
import multer from 'multer'
import XLSX from 'xlsx'
import { db } from '../lib/db'
import { requireEnterprise, AuthRequest } from '../middleware/auth'
import { bulkUploadQueue } from '../jobs/queues'

const router  = Router()
const storage = multer.memoryStorage()
const upload  = multer({ storage, limits: { fileSize: 20 * 1024 * 1024 } })

// ── GET MY ENTERPRISE ─────────────────────────────────────────────────────────
router.get('/me', requireEnterprise, async (req: AuthRequest, res, next) => {
  try {
    const ent = await db.enterprise.findUnique({
      where:   { userId: req.user!.id },
      include: { _count: { select: { employees: true, shifts: true } } },
    })
    if (!ent) return res.status(404).json({ error: 'Enterprise not found' })
    res.json({ enterprise: ent })
  } catch (err) { next(err) }
})

// ── UPDATE WHITE-LABEL SETTINGS ───────────────────────────────────────────────
router.patch('/settings', requireEnterprise, async (req: AuthRequest, res, next) => {
  try {
    const ent = await db.enterprise.findUnique({ where: { userId: req.user!.id } })
    if (!ent) return res.status(404).json({ error: 'Enterprise not found' })

    const allowed = ['companyName','logoUrl','brandColor','customDomain','smtpHost','smtpPort','smtpUser','fromEmailName','fromEmail']
    const data: any = {}
    for (const k of allowed) if (req.body[k] !== undefined) data[k] = req.body[k]

    const updated = await db.enterprise.update({ where: { id: ent.id }, data })
    res.json({ enterprise: updated })
  } catch (err) { next(err) }
})

// ── LIST EMPLOYEES ────────────────────────────────────────────────────────────
router.get('/employees', requireEnterprise, async (req: AuthRequest, res, next) => {
  try {
    const ent = await db.enterprise.findUnique({ where: { userId: req.user!.id } })
    if (!ent) return res.status(404).json({ error: 'Enterprise not found' })

    const { status, department, search, page = '1', limit = '50' } = req.query
    const skip  = (parseInt(page as string) - 1) * parseInt(limit as string)
    const where: any = { enterpriseId: ent.id }
    if (status)     where.status     = status
    if (department) where.department = department
    if (search)     where.OR = [
      { name:  { contains: search as string, mode: 'insensitive' } },
      { email: { contains: search as string, mode: 'insensitive' } },
    ]

    const [employees, total] = await Promise.all([
      db.employee.findMany({ where, skip, take: parseInt(limit as string), orderBy: { createdAt: 'desc' } }),
      db.employee.count({ where }),
    ])
    res.json({ employees, total })
  } catch (err) { next(err) }
})

// ── BULK UPLOAD (CSV / XLSX) ──────────────────────────────────────────────────
router.post('/employees/bulk', requireEnterprise, upload.single('file'), async (req: AuthRequest, res, next) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' })

    const ent = await db.enterprise.findUnique({ where: { userId: req.user!.id } })
    if (!ent) return res.status(404).json({ error: 'Enterprise not found' })

    // Parse CSV / XLSX using SheetJS
    const workbook = XLSX.read(req.file.buffer, { type: 'buffer' })
    const sheet    = workbook.Sheets[workbook.SheetNames[0]]
    const rows     = XLSX.utils.sheet_to_json<any>(sheet, { defval: '' })

    // Validate & normalise rows
    const VALID_TIERS = ['LIGHT','MEDIUM','HEAVY','EXTREME']
    const parsed = rows
      .filter(r => r.email && r.name)
      .map(r => ({
        name:        String(r.name   || r.Name   || '').trim(),
        email:       String(r.email  || r.Email  || '').trim().toLowerCase(),
        role:        String(r.role   || r.Role   || 'Staff').trim(),
        department:  String(r.department || r.Department || '').trim() || undefined,
        phone:       String(r.phone  || r.Phone  || '').trim() || undefined,
        weightTier:  VALID_TIERS.includes(String(r.weight_tier || r.weightTier || '').toUpperCase())
                       ? String(r.weight_tier || r.weightTier).toUpperCase()
                       : undefined,
      }))

    if (parsed.length === 0) return res.status(400).json({ error: 'No valid rows found. Required columns: name, email' })
    if (parsed.length > 2000) return res.status(400).json({ error: 'Maximum 2000 employees per upload' })

    // Queue the bulk processing job
    const job = await bulkUploadQueue.add('process', { enterpriseId: ent.id, rows: parsed }, {
      attempts: 3,
      backoff:  { type: 'exponential', delay: 2000 },
    })

    res.status(202).json({
      message:  `Processing ${parsed.length} employees — verification emails will be sent automatically`,
      jobId:    job.id,
      rowCount: parsed.length,
    })
  } catch (err) { next(err) }
})

// ── BULK UPLOAD PROGRESS ──────────────────────────────────────────────────────
router.get('/employees/bulk/:jobId/progress', requireEnterprise, async (req, res, next) => {
  try {
    const job = await bulkUploadQueue.getJob(req.params.jobId)
    if (!job) return res.status(404).json({ error: 'Upload job not found' })

    const state    = await job.getState()
    const progress = await job.progress

    res.json({ state, progress, result: state === 'completed' ? await job.returnvalue : null })
  } catch (err) { next(err) }
})

// ── ADD SINGLE EMPLOYEE ───────────────────────────────────────────────────────
router.post('/employees', requireEnterprise, async (req: AuthRequest, res, next) => {
  try {
    const ent = await db.enterprise.findUnique({ where: { userId: req.user!.id } })
    if (!ent) return res.status(404).json({ error: 'Enterprise not found' })

    const { emailQueue } = await import('../jobs/queues')
    const { v4: uuid }   = await import('uuid')
    const token  = uuid()
    const expiry = new Date(Date.now() + 1000 * 60 * 60 * 72)

    const employee = await db.employee.create({
      data: { ...req.body, enterpriseId: ent.id, verifyToken: token, verifyTokenExpiry: expiry },
    })

    await emailQueue.add('send', {
      type: 'employee-verification', to: employee.email,
      name: employee.name, token, enterpriseId: ent.id,
    })

    res.status(201).json({ employee })
  } catch (err) { next(err) }
})

// ── VERIFY EMPLOYEE TOKEN ─────────────────────────────────────────────────────
router.post('/employees/verify', async (req, res, next) => {
  try {
    const { token, password } = req.body
    const emp = await db.employee.findFirst({
      where: { verifyToken: token, verifyTokenExpiry: { gt: new Date() } },
    })
    if (!emp) return res.status(400).json({ error: 'Invalid or expired verification link' })

    const bcrypt = await import('bcryptjs')
    const hash   = await bcrypt.hash(password, 12)

    await db.employee.update({
      where: { id: emp.id },
      data:  { emailVerified: true, verifyToken: null, verifyTokenExpiry: null, passwordHash: hash, status: 'ACTIVE' },
    })
    res.json({ message: 'Account verified — you can now log in' })
  } catch (err) { next(err) }
})

// ── ATTENDANCE CLOCK IN/OUT ───────────────────────────────────────────────────
router.post('/employees/:id/clock-in', requireEnterprise, async (req: AuthRequest, res, next) => {
  try {
    const { lat, lng } = req.body
    await db.employee.update({ where: { id: req.params.id }, data: { clockedIn: true, lastClockIn: new Date() } })
    await db.attendance.create({
      data: { employeeId: req.params.id, date: new Date(), clockIn: new Date(), lat, lng },
    })
    res.json({ message: 'Clocked in' })
  } catch (err) { next(err) }
})

router.post('/employees/:id/clock-out', requireEnterprise, async (req: AuthRequest, res, next) => {
  try {
    const attendance = await db.attendance.findFirst({
      where: { employeeId: req.params.id, clockOut: null },
      orderBy: { createdAt: 'desc' },
    })
    if (attendance) {
      const hoursWorked = (Date.now() - attendance.clockIn!.getTime()) / 3_600_000
      await db.attendance.update({
        where: { id: attendance.id },
        data:  { clockOut: new Date(), hoursWorked },
      })
    }
    await db.employee.update({ where: { id: req.params.id }, data: { clockedIn: false, lastClockOut: new Date() } })
    res.json({ message: 'Clocked out' })
  } catch (err) { next(err) }
})

// ── GENERATE PAYSLIP ──────────────────────────────────────────────────────────
router.post('/employees/:id/payslip', requireEnterprise, async (req: AuthRequest, res, next) => {
  try {
    const ent = await db.enterprise.findUnique({ where: { userId: req.user!.id } })
    const emp = await db.employee.findUnique({ where: { id: req.params.id } })
    if (!ent || !emp) return res.status(404).json({ error: 'Not found' })

    const { generatePayslipPDF } = await import('../services/pdf')
    const { period, items, deductions, currency = 'USD' } = req.body

    const totalGross = items.reduce((s: number, i: any) => s + i.amount, 0)
    const totalDeductions = deductions.reduce((s: number, d: any) => s + d.amount, 0)

    const pdf = await generatePayslipPDF({
      companyName: ent.companyName,
      logoUrl:     ent.logoUrl ?? undefined,
      brandColor:  ent.brandColor,
      employeeName: emp.name,
      employeeRole: emp.role,
      period, items, totalGross, deductions,
      totalNet: totalGross - totalDeductions,
      currency,
    })

    res.set({ 'Content-Type': 'application/pdf', 'Content-Disposition': `attachment; filename="payslip-${emp.name}-${period}.pdf"` })
    res.send(pdf)
  } catch (err) { next(err) }
})

export default router
