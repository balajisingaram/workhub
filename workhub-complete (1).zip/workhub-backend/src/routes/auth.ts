import { Router } from 'express'
import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'
import { v4 as uuid } from 'uuid'
import { z } from 'zod'
import { db } from '../lib/db'
import { emailService } from '../services/email'
import { validate } from '../middleware/validate'

const router = Router()

const JWT_SECRET  = process.env.JWT_SECRET!
const JWT_REFRESH = process.env.JWT_REFRESH_SECRET!

function signAccess(payload: object)  { return jwt.sign(payload, JWT_SECRET,  { expiresIn: '15m' }) }
function signRefresh(payload: object) { return jwt.sign(payload, JWT_REFRESH, { expiresIn: '30d' }) }

// ── REGISTER ─────────────────────────────────────────────────────────────────
const RegisterSchema = z.object({
  email:       z.string().email(),
  password:    z.string().min(8),
  firstName:   z.string().min(1),
  lastName:    z.string().min(1),
  role:        z.enum(['CLIENT', 'FREELANCER', 'ONSITE_WORKER', 'ENTERPRISE']),
  companyName: z.string().optional(),
})

router.post('/register', validate(RegisterSchema), async (req, res, next) => {
  try {
    const { email, password, firstName, lastName, role, companyName } = req.body

    const existing = await db.user.findUnique({ where: { email } })
    if (existing) return res.status(409).json({ error: 'Email already in use' })

    const passwordHash    = await bcrypt.hash(password, 12)
    const emailVerifyToken = uuid()

    const user = await db.user.create({
      data: {
        email,
        passwordHash,
        role: role as any,
        emailVerifyToken,
        wallet: { create: { balance: 0 } },
      },
    })

    // Create role-specific profile
    if (role === 'FREELANCER') {
      await db.freelancerProfile.create({
        data: {
          userId:       user.id,
          title:        `${firstName} ${lastName}`,
          hourlyRateMin: 20,
          hourlyRateMax: 50,
        },
      })
    }

    if (role === 'ONSITE_WORKER') {
      const workerCode = `ON-${Math.floor(1000 + Math.random() * 9000)}`
      await db.onsiteWorkerProfile.create({
        data: { userId: user.id, workerCode, weightTier: 'LIGHT' },
      })
    }

    if (role === 'ENTERPRISE') {
      await db.enterprise.create({
        data: { userId: user.id, companyName: companyName ?? `${firstName}'s Company` },
      })
    }

    // Send verification email
    await emailService.sendVerificationEmail(email, `${firstName} ${lastName}`, emailVerifyToken)

    const payload = { id: user.id, email: user.email, role: user.role }
    res.status(201).json({
      message: 'Account created — check your email to verify',
      accessToken:  signAccess(payload),
      refreshToken: signRefresh(payload),
      user: { id: user.id, email: user.email, role: user.role },
    })
  } catch (err) { next(err) }
})

// ── VERIFY EMAIL ──────────────────────────────────────────────────────────────
router.get('/verify-email/:token', async (req, res, next) => {
  try {
    const user = await db.user.findFirst({ where: { emailVerifyToken: req.params.token } })
    if (!user) return res.status(400).json({ error: 'Invalid or expired verification link' })

    await db.user.update({
      where: { id: user.id },
      data:  { emailVerified: true, emailVerifyToken: null, status: 'ACTIVE' },
    })
    res.json({ message: 'Email verified successfully' })
  } catch (err) { next(err) }
})

// ── LOGIN ─────────────────────────────────────────────────────────────────────
const LoginSchema = z.object({
  email:    z.string().email(),
  password: z.string().min(1),
})

router.post('/login', validate(LoginSchema), async (req, res, next) => {
  try {
    const { email, password } = req.body

    const user = await db.user.findUnique({ where: { email } })
    if (!user) return res.status(401).json({ error: 'Invalid email or password' })
    if (user.status === 'SUSPENDED') return res.status(403).json({ error: 'Account suspended' })

    const valid = await bcrypt.compare(password, user.passwordHash)
    if (!valid) return res.status(401).json({ error: 'Invalid email or password' })

    await db.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } })

    const payload = { id: user.id, email: user.email, role: user.role }
    res.json({
      accessToken:  signAccess(payload),
      refreshToken: signRefresh(payload),
      user: { id: user.id, email: user.email, role: user.role, status: user.status },
    })
  } catch (err) { next(err) }
})

// ── REFRESH TOKEN ─────────────────────────────────────────────────────────────
router.post('/refresh', async (req, res, next) => {
  try {
    const { refreshToken } = req.body
    if (!refreshToken) return res.status(401).json({ error: 'Missing refresh token' })

    const payload = jwt.verify(refreshToken, JWT_REFRESH) as any
    const user    = await db.user.findUnique({ where: { id: payload.id } })
    if (!user || user.status === 'SUSPENDED') return res.status(401).json({ error: 'Unauthorized' })

    const newPayload = { id: user.id, email: user.email, role: user.role }
    res.json({ accessToken: signAccess(newPayload) })
  } catch {
    res.status(401).json({ error: 'Invalid refresh token' })
  }
})

// ── FORGOT PASSWORD ───────────────────────────────────────────────────────────
router.post('/forgot-password', async (req, res, next) => {
  try {
    const { email } = req.body
    const user = await db.user.findUnique({ where: { email } })
    // Always return success to prevent email enumeration
    if (user) {
      const token   = uuid()
      const expiry  = new Date(Date.now() + 1000 * 60 * 60) // 1 hour
      await db.user.update({ where: { id: user.id }, data: { resetToken: token, resetTokenExpiry: expiry } })
      await emailService.sendPasswordReset(email, token)
    }
    res.json({ message: 'If that email exists, a reset link has been sent' })
  } catch (err) { next(err) }
})

// ── RESET PASSWORD ────────────────────────────────────────────────────────────
router.post('/reset-password', async (req, res, next) => {
  try {
    const { token, newPassword } = req.body
    const user = await db.user.findFirst({
      where: { resetToken: token, resetTokenExpiry: { gt: new Date() } },
    })
    if (!user) return res.status(400).json({ error: 'Invalid or expired reset link' })

    const passwordHash = await bcrypt.hash(newPassword, 12)
    await db.user.update({
      where: { id: user.id },
      data:  { passwordHash, resetToken: null, resetTokenExpiry: null },
    })
    res.json({ message: 'Password updated successfully' })
  } catch (err) { next(err) }
})

// ── ME ────────────────────────────────────────────────────────────────────────
router.get('/me', async (req, res, next) => {
  try {
    const auth = req.headers.authorization?.slice(7)
    if (!auth) return res.status(401).json({ error: 'Unauthorized' })
    const payload = jwt.verify(auth, JWT_SECRET) as any
    const user    = await db.user.findUnique({
      where:  { id: payload.id },
      select: { id: true, email: true, role: true, status: true, kycVerified: true, emailVerified: true, createdAt: true },
    })
    if (!user) return res.status(404).json({ error: 'User not found' })
    res.json({ user })
  } catch {
    res.status(401).json({ error: 'Unauthorized' })
  }
})

export default router
