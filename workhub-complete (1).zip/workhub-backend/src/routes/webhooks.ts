import { Router } from 'express'
import { handleStripeWebhook } from '../services/payment'
import crypto from 'crypto'
import { db } from '../lib/db'

const router = Router()

// ── STRIPE WEBHOOK ────────────────────────────────────────────────────────────
router.post('/stripe', async (req, res, next) => {
  try {
    const sig = req.headers['stripe-signature'] as string
    if (!sig) return res.status(400).json({ error: 'Missing stripe-signature header' })
    await handleStripeWebhook(req.body as Buffer, sig)
    res.json({ received: true })
  } catch (err: any) {
    console.error('[Stripe webhook error]', err.message)
    res.status(400).json({ error: err.message })
  }
})

// ── RAZORPAY WEBHOOK ──────────────────────────────────────────────────────────
router.post('/razorpay', async (req, res, next) => {
  try {
    const body      = req.body as Buffer
    const signature = req.headers['x-razorpay-signature'] as string
    const secret    = process.env.RAZORPAY_WEBHOOK_SECRET!

    const expected = crypto.createHmac('sha256', secret).update(body).digest('hex')
    if (expected !== signature) return res.status(400).json({ error: 'Invalid signature' })

    const event = JSON.parse(body.toString())

    if (event.event === 'payment.captured') {
      const { order_id, id: paymentId } = event.payload.payment.entity
      await db.payment.updateMany({
        where: { razorpayOrderId: order_id },
        data:  { status: 'CAPTURED', razorpayPaymentId: paymentId, photoUnlocked: true },
      })
    }

    if (event.event === 'refund.created') {
      const { order_id } = event.payload.refund.entity
      await db.payment.updateMany({
        where: { razorpayOrderId: order_id },
        data:  { status: 'REFUNDED', refundedAt: new Date() },
      })
    }

    res.json({ received: true })
  } catch (err) { next(err) }
})

export default router
